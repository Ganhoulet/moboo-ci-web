<?php
if (!defined('ABSPATH')) exit;

/** Appels à l'API partenaires de Moboo.ci (clé « mbk_… » de l'agence). */
final class Moboo_Connect_Api {
    /** @return array|WP_Error */
    public static function request($method, $path, $body = null) {
        $o = Moboo_Connect::opts();
        if (!$o['key']) return new WP_Error('moboo_no_key', __('Renseignez votre clé API Moboo.ci (Réglages → Moboo.ci).', 'moboo-connect'));
        $args = [
            'method'  => $method,
            'timeout' => 45,
            'headers' => [
                'Authorization' => 'Bearer ' . $o['key'],
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
                'User-Agent'    => 'Moboo-Connect/' . MOBOO_CONNECT_VERSION . ' WordPress/' . get_bloginfo('version'),
            ],
        ];
        if ($body !== null) $args['body'] = wp_json_encode($body);
        $r = wp_remote_request(rtrim($o['api'], '/') . '/partner/v1' . $path, $args);
        if (is_wp_error($r)) return $r;
        $code = (int) wp_remote_retrieve_response_code($r);
        $data = json_decode(wp_remote_retrieve_body($r), true);
        if ($code >= 300) {
            $msg = is_array($data) && isset($data['error']['message']) ? $data['error']['message'] : ('HTTP ' . $code);
            if (is_array($msg)) $msg = implode(' ', $msg);
            return new WP_Error('moboo_api_' . $code, $msg, ['status' => $code]);
        }
        return is_array($data) ? $data : [];
    }

    public static function ref($post_id) {
        return 'wp-' . (int) $post_id;
    }
}
