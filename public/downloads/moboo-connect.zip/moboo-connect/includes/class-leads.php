<?php
if (!defined('ABSPATH')) exit;

/**
 * Demandes reçues sur Moboo.ci (contact, visite) : arrivent en temps réel par
 * webhook signé, enregistrées dans WordPress (menu « Demandes Moboo.ci ») et
 * envoyées par e-mail. Action pour les relier à un CRM : moboo_connect_lead.
 */
final class Moboo_Connect_Leads {
    const CPT = 'moboo_lead';

    public static function init() {
        register_post_type(self::CPT, [
            'labels' => ['name' => __('Demandes Moboo.ci', 'moboo-connect'), 'singular_name' => __('Demande Moboo.ci', 'moboo-connect')],
            'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-email-alt', 'menu_position' => 26,
            'supports' => ['title'], 'capability_type' => 'post', 'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
        ]);
        add_filter('manage_' . self::CPT . '_posts_columns', function () {
            return ['cb' => '<input type="checkbox">', 'title' => __('Client', 'moboo-connect'), 'moboo_phone' => __('Téléphone', 'moboo-connect'), 'moboo_kind' => __('Demande', 'moboo-connect'), 'moboo_property' => __('Bien', 'moboo-connect'), 'date' => __('Date', 'moboo-connect')];
        });
        add_action('manage_' . self::CPT . '_posts_custom_column', [__CLASS__, 'column'], 10, 2);
        add_action('add_meta_boxes_' . self::CPT, function () {
            add_meta_box('moboo-lead', __('Détails', 'moboo-connect'), [__CLASS__, 'render'], null, 'normal', 'high');
        });
    }

    public static function register_rest() {
        add_action('rest_api_init', function () {
            register_rest_route('moboo/v1', '/webhook', ['methods' => 'POST', 'callback' => [__CLASS__, 'webhook'], 'permission_callback' => '__return_true']);
        });
    }

    public static function webhook_url() {
        return rest_url('moboo/v1/webhook');
    }

    /** Signature « t=…,v1=HMAC-SHA256(t.corps) » avec le secret reçu à la connexion. */
    public static function verify($body, $header, $secret) {
        if (!$secret || !preg_match('/^t=(\d+),v1=([0-9a-f]{64})$/', (string) $header, $m)) return false;
        if (abs(time() - (int) $m[1]) > 300) return false;
        return hash_equals(hash_hmac('sha256', $m[1] . '.' . $body, $secret), $m[2]);
    }

    public static function webhook(WP_REST_Request $req) {
        $body = $req->get_body();
        if (!self::verify($body, $req->get_header('x-moboo-signature'), Moboo_Connect::opts()['webhook_secret'])) {
            return new WP_REST_Response(['ok' => false, 'error' => 'signature'], 401);
        }
        $evt = json_decode($body, true);
        if (!is_array($evt) || empty($evt['type'])) return new WP_REST_Response(['ok' => false], 400);
        if ($evt['type'] === 'lead.created' && !empty($evt['data']['id'])) self::save($evt['data']);
        return new WP_REST_Response(['ok' => true], 200);
    }

    /** Enregistre la demande (une seule fois, même si Moboo la renvoie) et prévient par e-mail. */
    public static function save(array $l) {
        $existing = get_posts(['post_type' => self::CPT, 'post_status' => 'any', 'meta_key' => '_moboo_lead_id', 'meta_value' => $l['id'], 'fields' => 'ids', 'numberposts' => 1]);
        if ($existing) return (int) $existing[0];
        $property = (!empty($l['externalRef']) && preg_match('/^wp-(\d+)$/', $l['externalRef'], $m)) ? (int) $m[1] : 0;
        $kinds = ['visit' => __('Demande de visite', 'moboo-connect'), 'reservation' => __('Réservation', 'moboo-connect'), 'contact' => __('Demande de contact', 'moboo-connect')];
        $kind = isset($kinds[$l['kind'] ?? '']) ? $kinds[$l['kind']] : $kinds['contact'];
        $id = wp_insert_post([
            'post_type' => self::CPT, 'post_status' => 'private',
            'post_title' => sanitize_text_field(($l['name'] ?? '') ?: ($l['phone'] ?? 'Client')),
            'post_content' => sanitize_textarea_field($l['message'] ?? ''),
        ], true);
        if (is_wp_error($id)) return 0;
        foreach (['id' => '_moboo_lead_id', 'phone' => '_moboo_phone', 'email' => '_moboo_email', 'kind' => '_moboo_kind', 'preferredDate' => '_moboo_date', 'listingTitle' => '_moboo_listing_title', 'listingId' => '_moboo_listing_id'] as $k => $meta) {
            if (isset($l[$k])) update_post_meta($id, $meta, sanitize_text_field((string) $l[$k]));
        }
        if ($property) update_post_meta($id, '_moboo_property', $property);

        $to = Moboo_Connect::opts()['lead_email'];
        if ($to) {
            $title = $property ? get_the_title($property) : ($l['listingTitle'] ?? '');
            $lines = [
                $kind . ($title ? ' — ' . $title : ''),
                '',
                __('Nom', 'moboo-connect') . ' : ' . ($l['name'] ?? ''),
                __('Téléphone', 'moboo-connect') . ' : ' . ($l['phone'] ?? ''),
                !empty($l['email']) ? 'E-mail : ' . $l['email'] : '',
                !empty($l['preferredDate']) ? __('Date souhaitée', 'moboo-connect') . ' : ' . $l['preferredDate'] : '',
                '',
                (string) ($l['message'] ?? ''),
                '',
                $property ? get_permalink($property) : '',
                admin_url('edit.php?post_type=' . self::CPT),
            ];
            wp_mail($to, sprintf('[Moboo.ci] %s — %s', $kind, $l['name'] ?? ''), implode("\n", array_filter($lines, function ($x) { return $x !== null; })), !empty($l['email']) ? ['Reply-To: ' . sanitize_email($l['email'])] : []);
        }
        /** Relier la demande à un CRM, un autre outil… */
        do_action('moboo_connect_lead', $l, $property, $id);
        return $id;
    }

    public static function column($col, $id) {
        if ($col === 'moboo_phone') {
            $p = get_post_meta($id, '_moboo_phone', true);
            echo $p ? '<a href="tel:' . esc_attr($p) . '">' . esc_html($p) . '</a> · <a href="https://wa.me/' . esc_attr(preg_replace('/\D/', '', $p)) . '" target="_blank" rel="noopener">WhatsApp</a>' : '—';
        } elseif ($col === 'moboo_kind') {
            $k = get_post_meta($id, '_moboo_kind', true);
            echo esc_html($k === 'visit' ? __('Visite', 'moboo-connect') . (($d = get_post_meta($id, '_moboo_date', true)) ? ' · ' . $d : '') : ($k === 'reservation' ? __('Réservation', 'moboo-connect') : __('Contact', 'moboo-connect')));
        } elseif ($col === 'moboo_property') {
            $p = (int) get_post_meta($id, '_moboo_property', true);
            echo $p ? '<a href="' . esc_url(get_edit_post_link($p)) . '">' . esc_html(get_the_title($p)) . '</a>' : esc_html(get_post_meta($id, '_moboo_listing_title', true));
        }
    }

    public static function render($post) {
        $rows = [
            __('Téléphone', 'moboo-connect') => get_post_meta($post->ID, '_moboo_phone', true),
            'E-mail' => get_post_meta($post->ID, '_moboo_email', true),
            __('Date souhaitée', 'moboo-connect') => get_post_meta($post->ID, '_moboo_date', true),
            __('Annonce', 'moboo-connect') => get_post_meta($post->ID, '_moboo_listing_title', true),
        ];
        echo '<table class="form-table">';
        foreach ($rows as $k => $v) if ($v) echo '<tr><th>' . esc_html($k) . '</th><td>' . esc_html($v) . '</td></tr>';
        echo '<tr><th>' . esc_html__('Message', 'moboo-connect') . '</th><td>' . nl2br(esc_html($post->post_content)) . '</td></tr></table>';
    }
}
