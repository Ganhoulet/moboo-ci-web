<?php
if (!defined('ABSPATH')) exit;

/**
 * Traduit un contenu WordPress en annonce Moboo.ci, pour n'importe quel thème :
 * modèles prêts pour Houzez, RealHomes et WP Residence, et correspondance libre
 * (champ personnalisé, taxonomie, image à la une, galerie, ACF) pour tout autre site.
 *
 * Source d'un champ : ['type' => 'meta'|'tax'|'title'|'content'|'excerpt'|'featured'|'gallery'|'attached'|'fixed'|'none', 'key' => '…']
 */
final class Moboo_Connect_Mapper {
    /** Champs Moboo.ci réglables. */
    const FIELDS = [
        'transaction'  => 'À louer / à vendre (statut)',
        'propertyType' => 'Type de bien',
        'price'        => 'Prix (FCFA)',
        'pricePostfix' => 'Période du loyer (ex. « /mois »)',
        'city'         => 'Ville',
        'commune'      => 'Commune / quartier',
        'address'      => 'Adresse',
        'latitude'     => 'Latitude',
        'longitude'    => 'Longitude',
        'location'     => 'Position « lat,lng » (un seul champ)',
        'bedrooms'     => 'Chambres',
        'bathrooms'    => 'Salles de bain',
        'garage'       => 'Parkings / garages',
        'surface'      => 'Surface (m²)',
        'yearBuilt'    => 'Année de construction',
        'features'     => 'Équipements',
        'photos'       => 'Galerie de photos',
        'videoUrl'     => 'Vidéo (YouTube)',
        'contactPhone' => 'Téléphone de contact (facultatif)',
    ];

    /** Modèles des thèmes immobiliers courants. */
    public static function presets() {
        $m = function ($k) { return ['type' => 'meta', 'key' => $k]; };
        $t = function ($k) { return ['type' => 'tax', 'key' => $k]; };
        return [
            'houzez' => ['label' => 'Houzez', 'post_type' => 'property', 'map' => [
                'transaction' => $t('property_status'), 'propertyType' => $t('property_type'), 'price' => $m('fave_property_price'),
                'pricePostfix' => $m('fave_property_price_postfix'), 'city' => $t('property_city'), 'commune' => $t('property_area'),
                'address' => $m('fave_property_map_address'), 'latitude' => $m('houzez_geolocation_lat'), 'longitude' => $m('houzez_geolocation_long'),
                'location' => $m('fave_property_location'), 'bedrooms' => $m('fave_property_bedrooms'), 'bathrooms' => $m('fave_property_bathrooms'),
                'garage' => $m('fave_property_garage'), 'surface' => $m('fave_property_size'), 'yearBuilt' => $m('fave_property_year'),
                'features' => $t('property_feature'), 'photos' => ['type' => 'gallery', 'key' => 'fave_property_images'], 'videoUrl' => $m('fave_video_url'),
            ]],
            'realhomes' => ['label' => 'RealHomes', 'post_type' => 'property', 'map' => [
                'transaction' => $t('property-status'), 'propertyType' => $t('property-type'), 'price' => $m('REAL_HOMES_property_price'),
                'pricePostfix' => $m('REAL_HOMES_property_price_postfix'), 'city' => $t('property-city'), 'commune' => ['type' => 'none', 'key' => ''],
                'address' => $m('REAL_HOMES_property_address'), 'location' => $m('REAL_HOMES_property_location'),
                'bedrooms' => $m('REAL_HOMES_property_bedrooms'), 'bathrooms' => $m('REAL_HOMES_property_bathrooms'), 'garage' => $m('REAL_HOMES_property_garage'),
                'surface' => $m('REAL_HOMES_property_size'), 'yearBuilt' => $m('REAL_HOMES_property_year_built'), 'features' => $t('property-feature'),
                'photos' => ['type' => 'gallery', 'key' => 'REAL_HOMES_property_images'], 'videoUrl' => $m('REAL_HOMES_tour_video_url'),
            ]],
            'wpresidence' => ['label' => 'WP Residence', 'post_type' => 'estate_property', 'map' => [
                'transaction' => $t('property_action_category'), 'propertyType' => $t('property_category'), 'price' => $m('property_price'),
                'pricePostfix' => $m('property_label'), 'city' => $t('property_city'), 'commune' => $t('property_area'),
                'address' => $m('property_address'), 'latitude' => $m('property_latitude'), 'longitude' => $m('property_longitude'),
                'bedrooms' => $m('property_bedrooms'), 'bathrooms' => $m('property_bathrooms'), 'garage' => $m('property-garage'),
                'surface' => $m('property_size'), 'yearBuilt' => $m('property-year'), 'features' => $t('property_features'),
                'photos' => ['type' => 'attached', 'key' => ''], 'videoUrl' => $m('embed_video_id'),
            ]],
        ];
    }

    /** Modèle du thème actif (ou null : correspondance à régler). */
    public static function detect() {
        $theme = strtolower(wp_get_theme()->get_template() . ' ' . wp_get_theme()->get('Name'));
        foreach (['houzez' => 'houzez', 'realhomes' => 'realhomes', 'real-homes' => 'realhomes', 'wpresidence' => 'wpresidence', 'wp residence' => 'wpresidence'] as $needle => $preset) {
            if (strpos($theme, $needle) !== false) return $preset;
        }
        return post_type_exists('property') && taxonomy_exists('property_status') ? 'houzez' : null;
    }

    /** Correspondance en vigueur : modèle choisi, complété par les réglages manuels. */
    public static function config() {
        $o = Moboo_Connect::opts();
        $presets = self::presets();
        $preset = $o['preset'] === 'auto' ? self::detect() : $o['preset'];
        $map = $preset && isset($presets[$preset]) ? $presets[$preset]['map'] : [];
        foreach ((array) $o['map'] as $field => $src) if (!empty($src['type'])) $map[$field] = $src;
        $pt = $o['preset'] === 'custom' || !$preset ? $o['post_type'] : $presets[$preset]['post_type'];
        return ['preset' => $preset ?: 'custom', 'post_type' => $pt, 'map' => $map];
    }

    public static function post_type() {
        return self::config()['post_type'];
    }

    // ─── Lecture des sources ──────────────────────────────────────────────
    /** Valeurs brutes (liste de textes) d'une source pour un contenu. */
    public static function read($post_id, $src) {
        $type = isset($src['type']) ? $src['type'] : 'none';
        $key = isset($src['key']) ? $src['key'] : '';
        $p = get_post($post_id);
        switch ($type) {
            case 'title': return [get_the_title($post_id)];
            case 'content': return [$p ? $p->post_content : ''];
            case 'excerpt': return [$p ? $p->post_excerpt : ''];
            case 'fixed': return [$key];
            case 'tax':
                $terms = $key ? get_the_terms($post_id, $key) : false;
                return is_array($terms) ? array_map(function ($t) { return html_entity_decode($t->name, ENT_QUOTES, 'UTF-8') . '|' . $t->slug; }, $terms) : [];
            case 'meta':
                if (!$key) return [];
                $vals = function_exists('get_field') ? get_field($key, $post_id, false) : null; // ACF : valeur brute
                if ($vals === null || $vals === false || $vals === '') $vals = get_post_meta($post_id, $key, false);
                $out = [];
                foreach ((array) $vals as $v) {
                    if (is_array($v)) { foreach ($v as $x) if (is_scalar($x)) $out[] = (string) $x; }
                    elseif (is_scalar($v)) $out[] = (string) $v;
                }
                return $out;
            default: return [];
        }
    }

    private static function first($post_id, $field, $map) {
        if (empty($map[$field])) return '';
        $v = self::read($post_id, $map[$field]);
        return $v ? trim(explode('|', (string) $v[0])[0]) : '';
    }

    /** Statut du site → transaction / état Moboo (devinette, modifiable dans les réglages). */
    public static function guess_status($slug, $name) {
        $s = remove_accents(strtolower($slug . ' ' . $name));
        if (preg_match('/vendu|sold/', $s)) return 'sold';
        if (preg_match('/\bloue\b|rented|deja loue/', $s)) return 'rented';
        if (preg_match('/rent|louer|location|bail|lease/', $s)) return 'rent';
        if (preg_match('/sale|vend|vente|achat|buy/', $s)) return 'sale';
        return 'skip';
    }

    const TYPES = [
        'studio' => 'studio', 'duplex' => 'duplex', 'triplex' => 'duplex', 'villa' => 'villa',
        'maison' => 'maison', 'house' => 'maison', 'basse' => 'maison', 'appart' => 'appartement', 'apartment' => 'appartement',
        'flat' => 'appartement', 'chambre' => 'appartement', 'terrain' => 'terrain', 'land' => 'terrain', 'lot' => 'terrain',
        'bureau' => 'bureau', 'office' => 'bureau', 'magasin' => 'magasin', 'boutique' => 'magasin', 'local' => 'magasin', 'shop' => 'magasin',
        'commerc' => 'magasin', 'entrep' => 'entrepot', 'warehouse' => 'entrepot', 'immeuble' => 'immeuble', 'building' => 'immeuble',
        'meubl' => 'residence-meublee',
    ];

    public static function guess_type($name) {
        $s = remove_accents(strtolower((string) $name));
        foreach (self::TYPES as $needle => $type) if (strpos($s, $needle) !== false) return $type;
        return 'autre';
    }

    private static function num($v) {
        $v = preg_replace('/[^\d.,]/', '', (string) $v);
        if ($v === '') return null;
        // « 350.000 » / « 350,000 » : séparateurs de milliers (pas de centimes en FCFA).
        if (preg_match('/^\d{1,3}([.,]\d{3})+$/', $v)) $v = preg_replace('/[.,]/', '', $v);
        return (float) str_replace(',', '.', $v);
    }

    /** Valeurs du statut (taxonomie ou champ) : [slug => nom]. */
    public static function status_values($post_id, $map) {
        $out = [];
        if (empty($map['transaction'])) return $out;
        foreach (self::read($post_id, $map['transaction']) as $v) {
            $parts = explode('|', $v);
            $out[isset($parts[1]) ? $parts[1] : sanitize_title($parts[0])] = $parts[0];
        }
        return $out;
    }

    public static function status($post_id, $map) {
        $rules = (array) Moboo_Connect::opts()['statuses'];
        $out = ['transaction' => null, 'state' => 'ACTIVE'];
        foreach (self::status_values($post_id, $map) as $slug => $name) {
            $m = isset($rules[$slug]) ? $rules[$slug] : self::guess_status($slug, $name);
            if ($m === 'rent' || $m === 'sale') $out['transaction'] = $m;
            if ($m === 'sold') { $out['state'] = 'SOLD'; $out['transaction'] = $out['transaction'] ?: 'sale'; }
            if ($m === 'rented') { $out['state'] = 'RENTED'; $out['transaction'] = $out['transaction'] ?: 'rent'; }
        }
        return $out;
    }

    /** Photos : image à la une puis galerie (identifiants de médias ou adresses), 12 au plus. */
    public static function photos($post_id, $map) {
        $ids = [];
        $urls = [];
        $thumb = (int) get_post_thumbnail_id($post_id);
        if ($thumb) $ids[] = $thumb;
        $src = isset($map['photos']) ? $map['photos'] : ['type' => 'none'];
        if ($src['type'] === 'attached') {
            foreach (get_attached_media('image', $post_id) as $a) $ids[] = $a->ID;
        } elseif (in_array($src['type'], ['gallery', 'meta'], true)) {
            foreach (self::read($post_id, ['type' => 'meta', 'key' => $src['key']]) as $v) {
                foreach (preg_split('/[\s,]+/', $v) as $x) {
                    if (ctype_digit($x)) $ids[] = (int) $x;
                    elseif (preg_match('#^https?://#', $x)) $urls[] = $x;
                }
            }
        }
        foreach (array_unique($ids) as $id) {
            $u = wp_get_attachment_image_url($id, 'full');
            if ($u) $urls[] = $u;
        }
        return array_slice(array_values(array_unique(array_filter($urls, function ($u) { return (bool) preg_match('#^https?://#', $u); }))), 0, 12);
    }

    private static function text($html) {
        $html = strip_shortcodes((string) $html);
        $html = preg_replace('#</(p|div|h[1-6]|li)>|<br\s*/?>#i', "\n", $html);
        $txt = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES, 'UTF-8');
        return trim(preg_replace("/\n{3,}/", "\n\n", preg_replace('/[ \t]+/', ' ', $txt)));
    }

    /** Annonce Moboo.ci, ou WP_Error si le contenu ne peut pas être publié. */
    public static function listing($post_id) {
        $p = get_post($post_id);
        if (!$p) return new WP_Error('moboo_missing', 'Contenu introuvable.');
        $map = self::config()['map'];
        $st = self::status($post_id, $map);
        if (!$st['transaction']) return new WP_Error('moboo_status', __('À louer ou à vendre ? Statut inconnu : réglez la correspondance des statuts (Réglages → Moboo.ci).', 'moboo-connect'));

        $f = function ($k) use ($post_id, $map) { return self::first($post_id, $k, $map); };
        $postfix = remove_accents(strtolower($f('pricePostfix')));
        $unit = preg_match('/jour|nuit|day|night/', $postfix) ? 'day' : (preg_match('/semaine|week/', $postfix) ? 'week' : (preg_match('/\ban\b|annee|year/', $postfix) ? 'year' : 'month'));
        $lat = $f('latitude');
        $lng = $f('longitude');
        if ((!$lat || !$lng) && ($loc = $f('location'))) {
            $parts = array_map('trim', explode(',', $loc));
            if (count($parts) >= 2) { $lat = $parts[0]; $lng = $parts[1]; }
        }
        $int = function ($k) use ($f) { $v = self::num($f($k)); return $v === null ? null : (int) round($v); };
        $features = [];
        if (!empty($map['features'])) foreach (self::read($post_id, $map['features']) as $v) $features[] = explode('|', $v)[0];

        $data = [
            'title'        => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'),
            'description'  => self::text($p->post_content),
            'transaction'  => $st['transaction'],
            'propertyType' => self::guess_type($f('propertyType')),
            'price'        => self::num($f('price')),
            'city'         => $f('city'),
            'commune'      => $f('commune'),
            'address'      => $f('address'),
            'bedrooms'     => $int('bedrooms'),
            'bathrooms'    => $int('bathrooms'),
            'garage'       => $int('garage'),
            'surface'      => self::num($f('surface')),
            'yearBuilt'    => $int('yearBuilt'),
            'features'     => array_values(array_unique(array_filter($features))),
            'photos'       => self::photos($post_id, $map),
            'videoUrl'     => $f('videoUrl'),
            'contactPhone' => $f('contactPhone'),
        ];
        if ($st['transaction'] === 'rent') $data['priceUnit'] = $unit;
        if (is_numeric($lat) && is_numeric($lng) && abs((float) $lat) <= 90 && abs((float) $lng) <= 180 && ((float) $lat || (float) $lng)) {
            $data['latitude'] = (float) $lat;
            $data['longitude'] = (float) $lng;
        }
        if ($data['price'] === null) return new WP_Error('moboo_price', __('Prix manquant : Moboo.ci exige un prix.', 'moboo-connect'));
        if ($data['city'] === '') return new WP_Error('moboo_city', __('Ville manquante.', 'moboo-connect'));
        $data = array_filter($data, function ($v) { return $v !== null && $v !== '' && $v !== []; });

        /** Adapter l'annonce envoyée (champs calculés, autre extension…). */
        $data = apply_filters('moboo_connect_listing_data', $data, $post_id);
        return ['listing' => $data, 'state' => $st['state']];
    }
}
