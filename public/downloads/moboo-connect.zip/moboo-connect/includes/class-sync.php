<?php
if (!defined('ABSPATH')) exit;

/**
 * Synchronisation des biens vers Moboo.ci : à chaque enregistrement (en tâche de
 * fond, l'enregistrement n'attend pas), retrait si le bien est dépublié ou
 * supprimé, synchronisation complète, nouvel essai horaire des échecs.
 *
 * Métadonnées du bien : _moboo_id, _moboo_url, _moboo_moderation, _moboo_state,
 * _moboo_synced_at, _moboo_error, _moboo_payment, _moboo_exclude.
 */
final class Moboo_Connect_Sync {
    const CRON = 'moboo_connect_retry';

    public static function init() {
        $pt = Moboo_Connect_Mapper::post_type();
        add_action('save_post_' . $pt, [__CLASS__, 'on_save'], 20, 2);
        add_action('transition_post_status', [__CLASS__, 'on_transition'], 10, 3);
        add_action('before_delete_post', [__CLASS__, 'on_delete']);
        add_action('moboo_connect_sync_one', [__CLASS__, 'sync_one']);
        add_action('moboo_connect_remove_one', [__CLASS__, 'remove_one']);
        add_action(self::CRON, [__CLASS__, 'retry_failed']);
        add_action('wp_ajax_moboo_connect_sync_now', [__CLASS__, 'ajax_sync_now']);
        add_action('wp_ajax_moboo_connect_bulk', [__CLASS__, 'ajax_bulk']);
        add_filter('manage_' . $pt . '_posts_columns', [__CLASS__, 'column']);
        add_action('manage_' . $pt . '_posts_custom_column', [__CLASS__, 'column_value'], 10, 2);
        add_action('add_meta_boxes_' . $pt, [__CLASS__, 'meta_box']);
    }

    public static function activate() {
        if (!wp_next_scheduled(self::CRON)) wp_schedule_event(time() + 600, 'hourly', self::CRON);
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CRON);
    }

    private static function eligible($post) {
        return $post && $post->post_type === Moboo_Connect_Mapper::post_type() && $post->post_status === 'publish' && !get_post_meta($post->ID, '_moboo_exclude', true);
    }

    // ─── Déclencheurs ─────────────────────────────────────────────────────
    public static function on_save($post_id, $post) {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id) || !Moboo_Connect::opts()['auto']) return;
        // Case « Ne pas publier sur Moboo.ci » de l'écran d'édition.
        if (isset($_POST['moboo_connect_box']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['moboo_connect_box'])), 'moboo_connect_box')) {
            update_post_meta($post_id, '_moboo_exclude', empty($_POST['moboo_exclude']) ? 0 : 1);
        }
        if (self::eligible($post)) self::schedule('moboo_connect_sync_one', $post_id);
        elseif (get_post_meta($post_id, '_moboo_id', true)) self::schedule('moboo_connect_remove_one', $post_id);
    }

    public static function on_transition($new, $old, $post) {
        if ($old === 'publish' && $new !== 'publish' && $post->post_type === Moboo_Connect_Mapper::post_type() && get_post_meta($post->ID, '_moboo_id', true)) {
            self::schedule('moboo_connect_remove_one', $post->ID);
        }
    }

    public static function on_delete($post_id) {
        $post = get_post($post_id);
        if ($post && $post->post_type === Moboo_Connect_Mapper::post_type() && get_post_meta($post_id, '_moboo_id', true)) {
            self::remove_one($post_id); // tout de suite : le bien n'existera plus ensuite
        }
    }

    /** Tâche de fond unique par bien (plusieurs enregistrements rapprochés = un envoi). */
    private static function schedule($hook, $post_id) {
        wp_clear_scheduled_hook('moboo_connect_sync_one', [$post_id]);
        wp_clear_scheduled_hook('moboo_connect_remove_one', [$post_id]);
        wp_schedule_single_event(time() + 5, $hook, [$post_id]);
    }

    // ─── Envoi ────────────────────────────────────────────────────────────
    /** @return true|WP_Error */
    public static function sync_one($post_id) {
        $post = get_post($post_id);
        if (!self::eligible($post)) return get_post_meta($post_id, '_moboo_id', true) ? self::remove_one($post_id) : true;
        $m = Moboo_Connect_Mapper::listing($post_id);
        if (is_wp_error($m)) return self::fail($post_id, $m);
        $r = Moboo_Connect_Api::request('PUT', '/listings/by-ref/' . rawurlencode(Moboo_Connect_Api::ref($post_id)), $m['listing']);
        if (is_wp_error($r)) return self::fail($post_id, $r);
        $l = isset($r['listing']) ? $r['listing'] : [];
        // Vendu / loué / remis en ligne : l'état suit le statut Houzez.
        if (!empty($l['id']) && isset($l['status']) && $l['status'] !== $m['state'] && !($l['status'] === 'DISABLED' && !empty($l['awaitingPayment']))) {
            $s = Moboo_Connect_Api::request('PATCH', '/listings/' . rawurlencode($l['id']) . '/status', ['status' => $m['state']]);
            if (!is_wp_error($s)) $l = $s;
        }
        update_post_meta($post_id, '_moboo_id', isset($l['id']) ? $l['id'] : '');
        update_post_meta($post_id, '_moboo_url', isset($l['url']) ? esc_url_raw($l['url']) : '');
        update_post_meta($post_id, '_moboo_moderation', isset($l['moderation']) ? $l['moderation'] : '');
        update_post_meta($post_id, '_moboo_state', isset($l['status']) ? $l['status'] : '');
        update_post_meta($post_id, '_moboo_payment', !empty($l['payment']['url']) ? esc_url_raw($l['payment']['url']) : (!empty($l['awaitingPayment']) ? 'pending' : ''));
        update_post_meta($post_id, '_moboo_synced_at', time());
        delete_post_meta($post_id, '_moboo_error');
        do_action('moboo_connect_synced', $post_id, $l);
        return true;
    }

    /** @return true|WP_Error */
    public static function remove_one($post_id) {
        $r = Moboo_Connect_Api::request('DELETE', '/listings/by-ref/' . rawurlencode(Moboo_Connect_Api::ref($post_id)));
        if (is_wp_error($r) && (int) ($r->get_error_data()['status'] ?? 0) !== 404) return self::fail($post_id, $r);
        foreach (['_moboo_id', '_moboo_url', '_moboo_moderation', '_moboo_state', '_moboo_payment', '_moboo_error'] as $k) delete_post_meta($post_id, $k);
        update_post_meta($post_id, '_moboo_synced_at', time());
        return true;
    }

    private static function fail($post_id, WP_Error $e) {
        update_post_meta($post_id, '_moboo_error', $e->get_error_message());
        update_post_meta($post_id, '_moboo_synced_at', time());
        return $e;
    }

    /** Toutes les heures : nouvel essai des biens en erreur (20 au plus). */
    public static function retry_failed() {
        $ids = get_posts(['post_type' => Moboo_Connect_Mapper::post_type(), 'post_status' => 'publish', 'fields' => 'ids', 'numberposts' => 20, 'meta_key' => '_moboo_error', 'orderby' => 'modified']);
        foreach ($ids as $id) self::sync_one($id);
    }

    // ─── Administration ───────────────────────────────────────────────────
    public static function ajax_sync_now() {
        $id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
        check_ajax_referer('moboo_connect_sync_' . $id);
        if (!current_user_can('edit_post', $id)) wp_send_json_error(['message' => 'Accès refusé.'], 403);
        $r = self::sync_one($id);
        if (is_wp_error($r)) wp_send_json_error(['message' => $r->get_error_message()]);
        wp_send_json_success(['html' => self::status_html($id)]);
    }

    /** Synchronisation complète, 5 biens par appel (la page enchaîne les appels). */
    public static function ajax_bulk() {
        check_ajax_referer('moboo_connect_bulk');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Accès refusé.'], 403);
        $offset = isset($_POST['offset']) ? max(0, (int) $_POST['offset']) : 0;
        $pt = Moboo_Connect_Mapper::post_type();
        $total = (int) wp_count_posts($pt)->publish;
        $ids = get_posts(['post_type' => $pt, 'post_status' => 'publish', 'fields' => 'ids', 'numberposts' => 5, 'offset' => $offset, 'orderby' => 'ID', 'order' => 'ASC']);
        $done = [];
        foreach ($ids as $id) {
            $r = self::sync_one($id);
            $done[] = ['id' => $id, 'title' => get_the_title($id), 'ok' => !is_wp_error($r), 'message' => is_wp_error($r) ? $r->get_error_message() : ''];
            if (is_wp_error($r) && strpos($r->get_error_code(), 'moboo_api_429') === 0) break; // limite atteinte : on ralentit
        }
        wp_send_json_success(['offset' => $offset + count($done), 'total' => $total, 'items' => $done, 'finished' => $offset + count($done) >= $total || !$ids]);
    }

    public static function status_html($post_id) {
        $err = get_post_meta($post_id, '_moboo_error', true);
        $url = get_post_meta($post_id, '_moboo_url', true);
        $mod = get_post_meta($post_id, '_moboo_moderation', true);
        $pay = get_post_meta($post_id, '_moboo_payment', true);
        $state = get_post_meta($post_id, '_moboo_state', true);
        if (get_post_meta($post_id, '_moboo_exclude', true)) return '<span style="color:#787c82">' . esc_html__('Exclu', 'moboo-connect') . '</span>';
        if ($err) return '<span style="color:#b32d2e">⚠ ' . esc_html($err) . '</span>';
        if (!$url) return '<span style="color:#787c82">—</span>';
        $label = $pay ? __('Publication à régler', 'moboo-connect') : ($mod === 'pending' ? __('En validation', 'moboo-connect') : ($mod === 'rejected' ? __('Refusée', 'moboo-connect') : ($state === 'SOLD' ? __('Vendu', 'moboo-connect') : ($state === 'RENTED' ? __('Loué', 'moboo-connect') : __('En ligne', 'moboo-connect')))));
        $color = $pay || $mod === 'pending' ? '#996800' : ($mod === 'rejected' ? '#b32d2e' : '#008a20');
        $out = '<a href="' . esc_url($url) . '" target="_blank" rel="noopener" style="color:' . $color . ';font-weight:600">● ' . esc_html($label) . '</a>';
        if ($pay && $pay !== 'pending') $out .= ' · <a href="' . esc_url($pay) . '" target="_blank" rel="noopener">' . esc_html__('Payer', 'moboo-connect') . '</a>';
        return $out;
    }

    public static function column($cols) {
        $cols['moboo'] = 'Moboo.ci';
        return $cols;
    }

    public static function column_value($col, $post_id) {
        if ($col === 'moboo') echo wp_kses_post(self::status_html($post_id));
    }

    public static function meta_box() {
        add_meta_box('moboo-connect', 'Moboo.ci', [__CLASS__, 'render_box'], null, 'side', 'high');
    }

    public static function render_box($post) {
        $nonce = wp_create_nonce('moboo_connect_sync_' . $post->ID);
        wp_nonce_field('moboo_connect_box', 'moboo_connect_box');
        $at = (int) get_post_meta($post->ID, '_moboo_synced_at', true);
        echo '<p id="moboo-connect-status">' . wp_kses_post(self::status_html($post->ID)) . '</p>';
        if ($at) echo '<p class="description">' . esc_html(sprintf(__('Dernier envoi : %s', 'moboo-connect'), wp_date(get_option('date_format') . ' H:i', $at))) . '</p>';
        echo '<p><label><input type="checkbox" name="moboo_exclude" value="1" ' . checked((bool) get_post_meta($post->ID, '_moboo_exclude', true), true, false) . '> ' . esc_html__('Ne pas publier sur Moboo.ci', 'moboo-connect') . '</label></p>';
        if ($post->post_status === 'publish') {
            echo '<p><button type="button" class="button" id="moboo-connect-now">' . esc_html__('Synchroniser maintenant', 'moboo-connect') . '</button></p>';
            ?>
            <script>
            document.getElementById('moboo-connect-now').addEventListener('click', function () {
                var b = this; b.disabled = true; b.textContent = '…';
                var f = new FormData(); f.append('action', 'moboo_connect_sync_now'); f.append('post_id', '<?php echo (int) $post->ID; ?>'); f.append('_ajax_nonce', '<?php echo esc_js($nonce); ?>');
                fetch(ajaxurl, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
                    document.getElementById('moboo-connect-status').innerHTML = r.success ? r.data.html : '<span style="color:#b32d2e">⚠ ' + (r.data && r.data.message ? r.data.message : 'Erreur') + '</span>';
                    b.disabled = false; b.textContent = '<?php echo esc_js(__('Synchroniser maintenant', 'moboo-connect')); ?>';
                });
            });
            </script>
            <?php
        }
    }
}
