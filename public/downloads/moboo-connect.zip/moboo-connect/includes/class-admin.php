<?php
if (!defined('ABSPATH')) exit;

/** Réglages → Moboo.ci : connexion, correspondance des champs, synchronisation, demandes. */
final class Moboo_Connect_Admin {
    const SLUG = 'moboo-connect';
    const SOURCES = [
        'none' => '— Aucun —', 'meta' => 'Champ personnalisé (ou ACF)', 'tax' => 'Taxonomie / catégorie', 'title' => 'Titre',
        'excerpt' => 'Extrait', 'fixed' => 'Valeur fixe', 'gallery' => 'Galerie (identifiants ou adresses d’images)', 'attached' => 'Images jointes au contenu',
    ];
    const STATUS_CHOICES = ['rent' => 'À louer', 'sale' => 'À vendre', 'rented' => 'Loué (retiré de la location)', 'sold' => 'Vendu', 'skip' => 'Ignorer'];

    public static function init() {
        add_action('admin_menu', function () {
            add_options_page('Moboo.ci', 'Moboo.ci', 'manage_options', self::SLUG, [__CLASS__, 'page']);
        });
        add_action('admin_post_moboo_connect_save', [__CLASS__, 'save']);
        add_filter('plugin_action_links_' . plugin_basename(MOBOO_CONNECT_FILE), function ($links) {
            array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=' . self::SLUG)) . '">' . esc_html__('Réglages', 'moboo-connect') . '</a>');
            return $links;
        });
        add_action('admin_notices', [__CLASS__, 'notice']);
    }

    private static function url($tab, $args = []) {
        return add_query_arg(array_merge(['page' => self::SLUG, 'tab' => $tab], $args), admin_url('options-general.php'));
    }

    public static function notice() {
        $o = Moboo_Connect::opts();
        if ($o['key'] || !current_user_can('manage_options') || (isset($_GET['page']) && $_GET['page'] === self::SLUG)) return;
        echo '<div class="notice notice-info"><p>' . wp_kses_post(sprintf(__('Moboo.ci Connect : <a href="%s">connectez votre compte agence</a> pour publier vos biens sur Moboo.ci.', 'moboo-connect'), esc_url(self::url('connexion')))) . '</p></div>';
    }

    // ─── Enregistrement ───────────────────────────────────────────────────
    public static function save() {
        if (!current_user_can('manage_options')) wp_die('Accès refusé.');
        check_admin_referer('moboo_connect_save');
        $do = isset($_POST['do']) ? sanitize_key($_POST['do']) : '';
        $tab = 'connexion';
        $msg = '';
        $err = '';
        if ($do === 'connect') {
            $api = esc_url_raw(trim(wp_unslash($_POST['api'] ?? '')));
            $key = sanitize_text_field(wp_unslash($_POST['key'] ?? ''));
            Moboo_Connect::update(['api' => $api ?: 'https://resi.moboo.ci/api/v1', 'key' => $key]);
            $me = Moboo_Connect_Api::request('GET', '/me');
            if (is_wp_error($me)) {
                $err = sprintf(__('Connexion impossible : %s', 'moboo-connect'), $me->get_error_message());
                Moboo_Connect::update(['account' => null]);
            } else {
                Moboo_Connect::update(['account' => $me]);
                $msg = sprintf(__('Connecté au compte « %s ».', 'moboo-connect'), $me['account']['name'] ?? '');
                // Demandes en temps réel : le site déclare lui-même son adresse de réception.
                if (in_array('leads:read', (array) ($me['scopes'] ?? []), true)) {
                    $w = Moboo_Connect_Api::request('PUT', '/webhook', ['url' => Moboo_Connect_Leads::webhook_url()]);
                    if (is_wp_error($w)) $err = sprintf(__('Demandes en temps réel non activées : %s', 'moboo-connect'), $w->get_error_message());
                    else Moboo_Connect::update(['webhook_secret' => $w['webhookSecret'] ?? '']);
                }
            }
        } elseif ($do === 'disconnect') {
            Moboo_Connect::update(['key' => '', 'account' => null, 'webhook_secret' => '']);
            $msg = __('Compte déconnecté.', 'moboo-connect');
        } elseif ($do === 'mapping') {
            $tab = 'correspondance';
            $map = [];
            foreach (array_keys(Moboo_Connect_Mapper::FIELDS) as $f) {
                $t = sanitize_key($_POST['src_type'][$f] ?? '');
                if ($t && isset(self::SOURCES[$t])) $map[$f] = ['type' => $t, 'key' => sanitize_text_field(wp_unslash($_POST['src_key'][$f] ?? ''))];
            }
            $statuses = [];
            foreach ((array) ($_POST['status'] ?? []) as $k => $v) {
                $v = sanitize_key($v);
                if (isset(self::STATUS_CHOICES[$v])) $statuses[sanitize_text_field(wp_unslash($k))] = $v;
            }
            $preset = sanitize_key($_POST['preset'] ?? 'auto');
            Moboo_Connect::update([
                'preset' => in_array($preset, ['auto', 'houzez', 'realhomes', 'wpresidence', 'custom'], true) ? $preset : 'auto',
                'post_type' => sanitize_key($_POST['post_type'] ?? 'post'), 'map' => $map, 'statuses' => $statuses,
            ]);
            $msg = __('Correspondance enregistrée.', 'moboo-connect');
        } elseif ($do === 'sync') {
            $tab = 'synchronisation';
            Moboo_Connect::update(['auto' => empty($_POST['auto']) ? 0 : 1]);
            $msg = __('Réglage enregistré.', 'moboo-connect');
        } elseif ($do === 'leads') {
            $tab = 'demandes';
            Moboo_Connect::update(['lead_email' => sanitize_email(wp_unslash($_POST['lead_email'] ?? ''))]);
            $msg = __('Réglage enregistré.', 'moboo-connect');
        }
        set_transient('moboo_connect_flash', ['msg' => $msg, 'err' => $err], 60);
        wp_safe_redirect(self::url($tab));
        exit;
    }

    // ─── Aides ────────────────────────────────────────────────────────────
    private static function meta_keys($pt) {
        global $wpdb;
        $keys = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT pm.meta_key FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = %s AND pm.meta_key NOT LIKE %s ORDER BY pm.meta_key LIMIT 400",
            $pt, $wpdb->esc_like('_') . '%'
        ));
        return $keys ?: [];
    }

    /** Valeurs possibles du statut (termes de la taxonomie ou valeurs du champ). */
    private static function status_options($src) {
        global $wpdb;
        if (($src['type'] ?? '') === 'tax' && taxonomy_exists($src['key'])) {
            $terms = get_terms(['taxonomy' => $src['key'], 'hide_empty' => false]);
            return is_array($terms) ? array_combine(wp_list_pluck($terms, 'slug'), wp_list_pluck($terms, 'name')) : [];
        }
        if (($src['type'] ?? '') === 'meta' && $src['key']) {
            $vals = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value <> '' LIMIT 50", $src['key']));
            $out = [];
            foreach ($vals as $v) $out[sanitize_title($v)] = $v;
            return $out;
        }
        return [];
    }

    // ─── Page ─────────────────────────────────────────────────────────────
    public static function page() {
        if (!current_user_can('manage_options')) return;
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'connexion';
        $tabs = ['connexion' => 'Connexion', 'correspondance' => 'Correspondance des champs', 'synchronisation' => 'Synchronisation', 'demandes' => 'Demandes'];
        $flash = get_transient('moboo_connect_flash');
        delete_transient('moboo_connect_flash');
        echo '<div class="wrap"><h1>Moboo.ci Connect</h1>';
        if (!empty($flash['msg'])) echo '<div class="notice notice-success"><p>' . esc_html($flash['msg']) . '</p></div>';
        if (!empty($flash['err'])) echo '<div class="notice notice-error"><p>' . esc_html($flash['err']) . '</p></div>';
        echo '<nav class="nav-tab-wrapper">';
        foreach ($tabs as $k => $l) echo '<a class="nav-tab' . ($tab === $k ? ' nav-tab-active' : '') . '" href="' . esc_url(self::url($k)) . '">' . esc_html($l) . '</a>';
        echo '</nav>';
        call_user_func([__CLASS__, 'tab_' . (isset($tabs[$tab]) ? $tab : 'connexion')]);
        echo '</div>';
    }

    private static function form_open($do) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="moboo_connect_save"><input type="hidden" name="do" value="' . esc_attr($do) . '">';
        wp_nonce_field('moboo_connect_save');
    }

    private static function tab_connexion() {
        $o = Moboo_Connect::opts();
        $acc = $o['account'];
        echo '<p>' . wp_kses_post(__('Créez une clé dans <strong>Mon espace → API &amp; intégrations</strong> sur <a href="https://moboo.ci/mon-espace/api" target="_blank" rel="noopener">moboo.ci</a> (accès ouvert par l’équipe Moboo aux agences partenaires), puis collez-la ici.', 'moboo-connect')) . '</p>';
        self::form_open('connect');
        echo '<table class="form-table"><tr><th><label for="mc-key">' . esc_html__('Clé API', 'moboo-connect') . '</label></th><td><input id="mc-key" name="key" type="password" class="regular-text code" autocomplete="off" value="' . esc_attr($o['key']) . '" placeholder="mbk_…"></td></tr>';
        echo '<tr><th><label for="mc-api">' . esc_html__('Adresse de l’API', 'moboo-connect') . '</label></th><td><input id="mc-api" name="api" class="regular-text code" value="' . esc_attr($o['api']) . '"><p class="description">' . esc_html__('À ne changer que sur demande de Moboo.', 'moboo-connect') . '</p></td></tr></table>';
        submit_button($acc ? __('Reconnecter / tester', 'moboo-connect') : __('Connecter', 'moboo-connect'));
        echo '</form>';
        if ($acc) {
            $q = $acc['quota'] ?? null;
            echo '<h2>' . esc_html__('Compte connecté', 'moboo-connect') . '</h2><table class="widefat striped" style="max-width:700px"><tbody>';
            echo '<tr><td>' . esc_html__('Agence', 'moboo-connect') . '</td><td><strong>' . esc_html($acc['account']['name'] ?? '') . '</strong> (' . esc_html($acc['account']['phone'] ?? '') . ')' . (!empty($acc['account']['verified']) ? ' ✔' : '') . '</td></tr>';
            echo '<tr><td>' . esc_html__('Droits de la clé', 'moboo-connect') . '</td><td>' . esc_html(implode(', ', (array) ($acc['scopes'] ?? []))) . '</td></tr>';
            if (is_array($q)) echo '<tr><td>' . esc_html__('Forfait', 'moboo-connect') . '</td><td>' . esc_html(isset($q['remaining']) && $q['remaining'] >= 0 ? sprintf(__('%d annonce(s) restante(s)', 'moboo-connect'), $q['remaining']) : __('Annonces illimitées ou payantes à l’unité', 'moboo-connect')) . '</td></tr>';
            echo '<tr><td>' . esc_html__('Demandes en temps réel', 'moboo-connect') . '</td><td>' . ($o['webhook_secret'] ? '✔ ' . esc_html(Moboo_Connect_Leads::webhook_url()) : esc_html__('Non activées (le site doit être en https)', 'moboo-connect')) . '</td></tr>';
            echo '</tbody></table>';
            self::form_open('disconnect');
            submit_button(__('Déconnecter', 'moboo-connect'), 'delete');
            echo '</form>';
        }
    }

    private static function tab_correspondance() {
        $o = Moboo_Connect::opts();
        $cfg = Moboo_Connect_Mapper::config();
        $presets = Moboo_Connect_Mapper::presets();
        $detected = Moboo_Connect_Mapper::detect();
        $pt = $cfg['post_type'];
        $taxes = get_object_taxonomies($pt, 'objects');
        $metas = self::meta_keys($pt);
        echo '<p>' . esc_html__('Indiquez où se trouve chaque information de vos biens. Les thèmes Houzez, RealHomes et WP Residence sont reconnus automatiquement ; pour tout autre thème ou extension, choisissez le type de contenu puis la source de chaque champ.', 'moboo-connect') . '</p>';
        self::form_open('mapping');
        echo '<table class="form-table"><tr><th>' . esc_html__('Modèle', 'moboo-connect') . '</th><td><select name="preset"><option value="auto"' . selected($o['preset'], 'auto', false) . '>' . esc_html(sprintf(__('Automatique (%s)', 'moboo-connect'), $detected ? $presets[$detected]['label'] : __('aucun thème reconnu', 'moboo-connect'))) . '</option>';
        foreach ($presets as $k => $p) echo '<option value="' . esc_attr($k) . '"' . selected($o['preset'], $k, false) . '>' . esc_html($p['label']) . '</option>';
        echo '<option value="custom"' . selected($o['preset'], 'custom', false) . '>' . esc_html__('Personnalisé (autre thème)', 'moboo-connect') . '</option></select></td></tr>';
        echo '<tr><th>' . esc_html__('Type de contenu des biens', 'moboo-connect') . '</th><td><select name="post_type">';
        foreach (get_post_types(['show_ui' => true], 'objects') as $t) {
            if (in_array($t->name, ['attachment', 'wp_block', 'wp_navigation', Moboo_Connect_Leads::CPT], true)) continue;
            echo '<option value="' . esc_attr($t->name) . '"' . selected($pt, $t->name, false) . '>' . esc_html($t->label . ' (' . $t->name . ')') . '</option>';
        }
        echo '</select><p class="description">' . esc_html__('Utilisé avec le modèle « Personnalisé » ; les modèles fixent leur propre type.', 'moboo-connect') . '</p></td></tr></table>';

        echo '<datalist id="mc-meta">';
        foreach ($metas as $k) echo '<option value="' . esc_attr($k) . '">';
        echo '</datalist><datalist id="mc-tax">';
        foreach ($taxes as $t) echo '<option value="' . esc_attr($t->name) . '">' . esc_html($t->label) . '</option>';
        echo '</datalist>';

        echo '<h2>' . esc_html__('Champs', 'moboo-connect') . '</h2><p class="description">' . esc_html__('Titre, description et image à la une sont toujours repris. Laissez « Aucun » pour garder la valeur du modèle.', 'moboo-connect') . '</p>';
        echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Moboo.ci</th><th>' . esc_html__('Source', 'moboo-connect') . '</th><th>' . esc_html__('Champ / taxonomie / valeur', 'moboo-connect') . '</th></tr></thead><tbody>';
        foreach (Moboo_Connect_Mapper::FIELDS as $f => $label) {
            $own = isset($o['map'][$f]) ? $o['map'][$f] : ['type' => '', 'key' => ''];
            $eff = isset($cfg['map'][$f]) ? $cfg['map'][$f] : ['type' => 'none', 'key' => ''];
            echo '<tr><td><strong>' . esc_html($label) . '</strong></td><td><select name="src_type[' . esc_attr($f) . ']"><option value="">' . esc_html(sprintf(__('Modèle : %s', 'moboo-connect'), self::SOURCES[$eff['type']] ?? $eff['type'])) . '</option>';
            foreach (self::SOURCES as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($own['type'], $k, false) . '>' . esc_html($l) . '</option>';
            echo '</select></td><td><input name="src_key[' . esc_attr($f) . ']" class="regular-text code" list="' . ($eff['type'] === 'tax' ? 'mc-tax' : 'mc-meta') . '" value="' . esc_attr($own['type'] ? $own['key'] : '') . '" placeholder="' . esc_attr($eff['key']) . '"></td></tr>';
        }
        echo '</tbody></table>';

        $opts = isset($cfg['map']['transaction']) ? self::status_options($cfg['map']['transaction']) : [];
        echo '<h2>' . esc_html__('Statuts : à louer, à vendre, vendu, loué', 'moboo-connect') . '</h2>';
        if (!$opts) echo '<p>' . esc_html__('Choisissez d’abord la source du champ « À louer / à vendre ».', 'moboo-connect') . '</p>';
        else {
            echo '<table class="widefat striped" style="max-width:600px"><tbody>';
            foreach ($opts as $slug => $name) {
                $cur = isset($o['statuses'][$slug]) ? $o['statuses'][$slug] : Moboo_Connect_Mapper::guess_status($slug, $name);
                echo '<tr><td>' . esc_html($name) . '</td><td><select name="status[' . esc_attr($slug) . ']">';
                foreach (self::STATUS_CHOICES as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($cur, $k, false) . '>' . esc_html($l) . '</option>';
                echo '</select></td></tr>';
            }
            echo '</tbody></table>';
        }
        submit_button(__('Enregistrer la correspondance', 'moboo-connect'));
        echo '</form>';

        // Aperçu : ce qui partirait vers Moboo.ci pour un bien (rien n'est envoyé).
        $sample = get_posts(['post_type' => $pt, 'post_status' => 'publish', 'numberposts' => 30]);
        $pick = isset($_GET['apercu']) ? (int) $_GET['apercu'] : ($sample ? $sample[0]->ID : 0);
        echo '<h2>' . esc_html__('Aperçu', 'moboo-connect') . '</h2>';
        if (!$sample) { echo '<p>' . esc_html__('Aucun contenu publié de ce type.', 'moboo-connect') . '</p>'; return; }
        echo '<form method="get"><input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '"><input type="hidden" name="tab" value="correspondance"><select name="apercu">';
        foreach ($sample as $s) echo '<option value="' . (int) $s->ID . '"' . selected($pick, $s->ID, false) . '>' . esc_html(get_the_title($s)) . '</option>';
        echo '</select> <button class="button">' . esc_html__('Voir', 'moboo-connect') . '</button></form>';
        $m = Moboo_Connect_Mapper::listing($pick);
        if (is_wp_error($m)) echo '<p style="color:#b32d2e">⚠ ' . esc_html($m->get_error_message()) . '</p>';
        else {
            echo '<table class="widefat striped" style="max-width:900px"><tbody>';
            foreach ($m['listing'] as $k => $v) {
                $val = is_array($v) ? implode("\n", $v) : (string) $v;
                echo '<tr><td style="width:180px"><code>' . esc_html($k) . '</code></td><td>' . nl2br(esc_html(mb_strimwidth($val, 0, 600, '…'))) . '</td></tr>';
            }
            echo '<tr><td><code>status</code></td><td>' . esc_html($m['state']) . '</td></tr></tbody></table>';
        }
    }

    private static function tab_synchronisation() {
        $o = Moboo_Connect::opts();
        $pt = Moboo_Connect_Mapper::post_type();
        $count = function ($key) use ($pt) {
            return count(get_posts(['post_type' => $pt, 'post_status' => 'publish', 'fields' => 'ids', 'numberposts' => -1, 'meta_key' => $key]));
        };
        $total = (int) wp_count_posts($pt)->publish;
        $synced = $count('_moboo_id');
        $errors = get_posts(['post_type' => $pt, 'post_status' => 'publish', 'numberposts' => 50, 'meta_key' => '_moboo_error']);
        echo '<p>' . esc_html(sprintf(__('%1$d bien(s) publié(s) · %2$d sur Moboo.ci · %3$d en erreur.', 'moboo-connect'), $total, $synced, count($errors))) . '</p>';
        self::form_open('sync');
        echo '<p><label><input type="checkbox" name="auto" value="1"' . checked($o['auto'], 1, false) . '> ' . esc_html__('Publier automatiquement sur Moboo.ci à chaque enregistrement (et retirer les biens dépubliés ou supprimés)', 'moboo-connect') . '</label></p>';
        submit_button(__('Enregistrer', 'moboo-connect'), 'secondary');
        echo '</form><h2>' . esc_html__('Tout synchroniser', 'moboo-connect') . '</h2><p>' . esc_html__('Envoie tous les biens publiés (5 par 5). Vous pouvez relancer sans risque : aucun doublon n’est créé.', 'moboo-connect') . '</p>';
        echo '<p><button type="button" class="button button-primary" id="mc-bulk"' . ($o['key'] ? '' : ' disabled') . '>' . esc_html__('Lancer la synchronisation', 'moboo-connect') . '</button> <span id="mc-progress"></span></p><ol id="mc-log" style="max-height:320px;overflow:auto"></ol>';
        ?>
        <script>
        (function () {
            var btn = document.getElementById('mc-bulk'), out = document.getElementById('mc-progress'), log = document.getElementById('mc-log');
            function step(offset) {
                var f = new FormData(); f.append('action', 'moboo_connect_bulk'); f.append('offset', offset); f.append('_ajax_nonce', '<?php echo esc_js(wp_create_nonce('moboo_connect_bulk')); ?>');
                fetch(ajaxurl, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
                    if (!r.success) { out.textContent = (r.data && r.data.message) || 'Erreur'; btn.disabled = false; return; }
                    r.data.items.forEach(function (it) { var li = document.createElement('li'); li.textContent = (it.ok ? '✔ ' : '⚠ ') + it.title + (it.message ? ' — ' + it.message : ''); li.style.color = it.ok ? '' : '#b32d2e'; log.appendChild(li); });
                    out.textContent = r.data.offset + ' / ' + r.data.total;
                    if (r.data.finished) { out.textContent += ' — <?php echo esc_js(__('terminé', 'moboo-connect')); ?>'; btn.disabled = false; } else step(r.data.offset);
                });
            }
            btn && btn.addEventListener('click', function () { btn.disabled = true; log.innerHTML = ''; step(0); });
        })();
        </script>
        <?php
        if ($errors) {
            echo '<h2>' . esc_html__('Biens en erreur', 'moboo-connect') . '</h2><p class="description">' . esc_html__('Nouvel essai automatique toutes les heures.', 'moboo-connect') . '</p><table class="widefat striped" style="max-width:900px"><tbody>';
            foreach ($errors as $p) echo '<tr><td><a href="' . esc_url(get_edit_post_link($p->ID)) . '">' . esc_html(get_the_title($p)) . '</a></td><td style="color:#b32d2e">' . esc_html(get_post_meta($p->ID, '_moboo_error', true)) . '</td></tr>';
            echo '</tbody></table>';
        }
    }

    private static function tab_demandes() {
        $o = Moboo_Connect::opts();
        echo '<p>' . esc_html__('Les demandes (contact, visite) faites sur Moboo.ci pour vos biens arrivent ici en temps réel et par e-mail.', 'moboo-connect') . '</p>';
        self::form_open('leads');
        echo '<table class="form-table"><tr><th><label for="mc-mail">' . esc_html__('E-mail de réception', 'moboo-connect') . '</label></th><td><input id="mc-mail" name="lead_email" type="email" class="regular-text" value="' . esc_attr($o['lead_email']) . '"></td></tr></table>';
        submit_button(__('Enregistrer', 'moboo-connect'), 'secondary');
        echo '</form>';
        $leads = get_posts(['post_type' => Moboo_Connect_Leads::CPT, 'post_status' => 'private', 'numberposts' => 10]);
        echo '<h2>' . esc_html__('Dernières demandes', 'moboo-connect') . '</h2>';
        if (!$leads) { echo '<p>' . esc_html__('Aucune demande pour le moment.', 'moboo-connect') . '</p>'; return; }
        echo '<table class="widefat striped" style="max-width:900px"><tbody>';
        foreach ($leads as $l) echo '<tr><td>' . esc_html(get_the_date('', $l) . ' ' . get_the_time('', $l)) . '</td><td><a href="' . esc_url(get_edit_post_link($l->ID)) . '">' . esc_html(get_the_title($l)) . '</a></td><td>' . esc_html(get_post_meta($l->ID, '_moboo_phone', true)) . '</td><td>' . esc_html(get_post_meta($l->ID, '_moboo_listing_title', true)) . '</td></tr>';
        echo '</tbody></table><p><a class="button" href="' . esc_url(admin_url('edit.php?post_type=' . Moboo_Connect_Leads::CPT)) . '">' . esc_html__('Toutes les demandes', 'moboo-connect') . '</a></p>';
    }
}
