<?php
if (!defined('ABSPATH')) exit;

/**
 * [moboo_annonces] : affiche sur le site les annonces de l'agence publiées sur
 * Moboo.ci (utile quand le site n'a pas son propre catalogue).
 * Attributs : nombre (12), colonnes (3), transaction (rent|sale), inclure_site (0 : les biens
 * venant déjà de ce site sont masqués pour éviter les doublons).
 */
final class Moboo_Connect_Shortcode {
    public static function init() {
        add_shortcode('moboo_annonces', [__CLASS__, 'render']);
    }

    private static function items() {
        $key = 'moboo_connect_listings';
        $cached = get_transient($key);
        if (is_array($cached)) return $cached;
        $r = Moboo_Connect_Api::request('GET', '/listings?status=ACTIVE&perPage=100');
        if (is_wp_error($r)) return [];
        $items = isset($r['items']) ? $r['items'] : [];
        set_transient($key, $items, 15 * MINUTE_IN_SECONDS);
        return $items;
    }

    public static function render($atts) {
        $a = shortcode_atts(['nombre' => 12, 'colonnes' => 3, 'transaction' => '', 'inclure_site' => 0], $atts, 'moboo_annonces');
        $items = array_filter(self::items(), function ($l) use ($a) {
            if (!$a['inclure_site'] && !empty($l['externalRef']) && strpos($l['externalRef'], 'wp-') === 0) return false;
            if ($a['transaction'] && ($l['transaction'] ?? '') !== $a['transaction']) return false;
            return ($l['moderation'] ?? 'approved') === 'approved';
        });
        $items = array_slice(array_values($items), 0, max(1, (int) $a['nombre']));
        if (!$items) return '<p class="moboo-annonces-vide">' . esc_html__('Aucune annonce pour le moment.', 'moboo-connect') . '</p>';
        $cols = max(1, min(4, (int) $a['colonnes']));
        $out = '<div class="moboo-annonces" style="display:grid;gap:20px;grid-template-columns:repeat(auto-fill,minmax(' . (int) (900 / $cols) . 'px,1fr))">';
        foreach ($items as $l) {
            $photo = !empty($l['photos'][0]) ? (is_array($l['photos'][0]) ? ($l['photos'][0]['url'] ?? '') : $l['photos'][0]) : '';
            $price = number_format((float) ($l['price'] ?? 0), 0, ',', ' ') . ' FCFA' . (($l['transaction'] ?? '') === 'rent' ? ' / ' . (($l['priceUnit'] ?? 'month') === 'day' ? 'jour' : 'mois') : '');
            $place = implode(', ', array_filter([$l['commune'] ?? '', $l['city'] ?? '']));
            $out .= '<a href="' . esc_url($l['url'] ?? '#') . '" target="_blank" rel="noopener" style="display:block;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;text-decoration:none;color:inherit;background:#fff">'
                . ($photo ? '<img src="' . esc_url($photo) . '" alt="" loading="lazy" style="width:100%;aspect-ratio:4/3;object-fit:cover;display:block">' : '<div style="aspect-ratio:4/3;background:#f1f5f9"></div>')
                . '<div style="padding:12px 14px"><div style="font-weight:700;color:#0555CC">' . esc_html($price) . '</div>'
                . '<div style="font-weight:600;margin:4px 0">' . esc_html($l['title'] ?? '') . '</div>'
                . '<div style="font-size:13px;color:#64748b">' . esc_html($place) . (!empty($l['bedrooms']) ? ' · ' . (int) $l['bedrooms'] . ' ch.' : '') . '</div></div></a>';
        }
        return $out . '</div><p style="font-size:12px;color:#94a3b8;margin-top:8px">' . esc_html__('Annonces publiées sur', 'moboo-connect') . ' <a href="https://moboo.ci" target="_blank" rel="noopener">Moboo.ci</a></p>';
    }
}
