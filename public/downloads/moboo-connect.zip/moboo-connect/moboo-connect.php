<?php
/**
 * Plugin Name:       Moboo.ci Connect
 * Plugin URI:        https://moboo.ci/developpeurs
 * Description:       Publie automatiquement les biens de votre site sur Moboo.ci (Houzez, RealHomes, WP Residence ou tout autre thème grâce à la correspondance des champs), reçoit les demandes des clients dans WordPress et affiche vos annonces Moboo.ci avec [moboo_annonces]. Réglages → Moboo.ci.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Moboo
 * Author URI:        https://moboo.ci
 * License:           GPLv2 or later
 * Text Domain:       moboo-connect
 */

if (!defined('ABSPATH')) exit;

define('MOBOO_CONNECT_VERSION', '1.0.0');
define('MOBOO_CONNECT_FILE', __FILE__);
define('MOBOO_CONNECT_DIR', plugin_dir_path(__FILE__));

require_once MOBOO_CONNECT_DIR . 'includes/class-api.php';
require_once MOBOO_CONNECT_DIR . 'includes/class-mapper.php';
require_once MOBOO_CONNECT_DIR . 'includes/class-sync.php';
require_once MOBOO_CONNECT_DIR . 'includes/class-leads.php';
require_once MOBOO_CONNECT_DIR . 'includes/class-shortcode.php';
require_once MOBOO_CONNECT_DIR . 'includes/class-admin.php';

/** Réglages de l'extension (une seule option). */
final class Moboo_Connect {
    const OPT = 'moboo_connect';

    public static function opts() {
        return wp_parse_args(get_option(self::OPT, []), [
            'api'           => 'https://resi.moboo.ci/api/v1',
            'key'           => '',
            'auto'          => 1,       // synchroniser à chaque enregistrement
            'preset'        => 'auto',  // auto | houzez | realhomes | wpresidence | custom
            'post_type'     => 'post',  // correspondance libre : type de contenu des biens
            'map'           => [],      // champ Moboo → source (voir Moboo_Connect_Mapper)
            'statuses'      => [],      // valeur du statut → rent | sale | sold | rented | skip
            'webhook_secret'=> '',
            'lead_email'    => get_option('admin_email'),
            'account'       => null,    // compte Moboo (réponse de /me), pour l'affichage
        ]);
    }

    public static function update($values) {
        update_option(self::OPT, array_merge(self::opts(), $values), false);
    }

    public static function init() {
        // Après l'enregistrement des types de contenu du thème (priorité 10).
        add_action('init', [__CLASS__, 'boot'], 20);
        Moboo_Connect_Leads::register_rest();
    }

    public static function boot() {
        Moboo_Connect_Sync::init();
        Moboo_Connect_Leads::init();
        Moboo_Connect_Shortcode::init();
        if (is_admin()) Moboo_Connect_Admin::init();
    }
}

add_action('plugins_loaded', ['Moboo_Connect', 'init']);
register_activation_hook(__FILE__, ['Moboo_Connect_Sync', 'activate']);
register_deactivation_hook(__FILE__, ['Moboo_Connect_Sync', 'deactivate']);
