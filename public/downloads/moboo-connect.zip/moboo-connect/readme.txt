=== Moboo.ci Connect ===
Contributors: moboo
Tags: immobilier, real estate, houzez, annonces, côte d'ivoire
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Publiez automatiquement les biens de votre agence sur Moboo.ci et recevez les demandes des clients dans WordPress.

== Description ==

* Publication automatique : chaque bien publié ou modifié part sur Moboo.ci (en tâche de fond) ; dépublié ou supprimé, il est retiré. Vendu / loué : l'annonce suit.
* Tous les thèmes : Houzez, RealHomes et WP Residence reconnus automatiquement ; pour tout autre thème ou extension, correspondance des champs (champ personnalisé, ACF, taxonomie, galerie) avec aperçu.
* Demandes en temps réel : contacts et visites reçus sur Moboo.ci arrivent dans « Demandes Moboo.ci » et par e-mail (webhook signé, site en https).
* [moboo_annonces] : affiche vos annonces Moboo.ci sur une page (attributs : nombre, colonnes, transaction=rent|sale, inclure_site=1).
* Synchronisation complète en un clic, nouvel essai automatique des erreurs, statut de chaque bien dans la liste.

Mêmes règles que sur moboo.ci : forfait, vérification du compte, validation par l'équipe Moboo.

== Installation ==

1. Extensions → Ajouter → Téléverser : moboo-connect.zip, puis activer.
2. Sur moboo.ci : Mon espace → API & intégrations → créer une clé (accès ouvert par Moboo aux agences partenaires).
3. Réglages → Moboo.ci : coller la clé, « Connecter ».
4. Onglet Correspondance : vérifier l'aperçu ; onglet Synchronisation : « Lancer la synchronisation ».

== Pour les développeurs ==

* Filtre moboo_connect_listing_data ($data, $post_id) : modifier l'annonce envoyée.
* Actions moboo_connect_synced ($post_id, $listing) et moboo_connect_lead ($lead, $property_id, $lead_post_id) : relier à un CRM.
* Documentation de l'API : https://moboo.ci/developpeurs
