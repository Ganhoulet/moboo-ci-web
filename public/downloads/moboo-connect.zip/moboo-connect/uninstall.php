<?php
// Suppression de l'extension : réglages et repères de synchronisation (les demandes reçues sont gardées).
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
delete_option('moboo_connect');
delete_transient('moboo_connect_listings');
global $wpdb;
$wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ('_moboo_id','_moboo_url','_moboo_moderation','_moboo_state','_moboo_synced_at','_moboo_error','_moboo_payment','_moboo_exclude')");
